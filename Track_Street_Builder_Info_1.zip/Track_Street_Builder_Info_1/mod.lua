
function data()
	return {
		info = {
			name = "Track/Street Builder Info",
			description = _("mod_desc"),
			minorVersion = 0,
			severityAdd = "NONE",
			severityRemove = "NONE",
			tags = {"Script Mod"},
			authors = {
				{
					name = "VacuumTube",
					role = "CREATOR",
					tfnetId = 29264,
				},
			},
		},
		runFn = function (settings)
			
		end,
		postRunFn = function (settings, modparams)
			
		end
	}
end